# React Component Demo App

## Running the code

- Check you are in the correct directory: `./solutions/react-posts`
- Install the necessary dependencies by running `npm install`
- Run the app by running `npm run dev`

## Running the tests

- Check you are in the correct directory: `./solutions/react-posts`
- If not installed, install the necessary dependencies by running `npm install`
- Run the tests by running `npm test`
