export const randomUnder100 = () => {
  return Math.floor(Math.random() * 100)
}
