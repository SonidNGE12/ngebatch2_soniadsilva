export function addToArray(arrayVariable: string[], itemToAdd: string) {
  arrayVariable.push(itemToAdd)

  return arrayVariable
}
