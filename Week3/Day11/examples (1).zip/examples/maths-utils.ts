// Cursor Park

// For examples of running this see maths-utils.test.ts

export function add(a: any, b: any) {
  return a + b
}

// EOF
