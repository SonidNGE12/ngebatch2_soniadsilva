# Example express app

This is a small example app to link the ideas of the APIS sessions to what we are doing in API Gateway.

In AWS we don't need to run a whole server - we can have bits of code in Lambdas - and then front that with API GAteway so it looks like an express app (has a variety of urls) and behaves like an express app (has code in it to do different things).
