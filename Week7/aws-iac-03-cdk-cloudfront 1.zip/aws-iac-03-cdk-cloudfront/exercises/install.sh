cd cdk;
npm i;
cd functions;
npm i;
cd ../../;
cd client;
npm i;
cd ..;
