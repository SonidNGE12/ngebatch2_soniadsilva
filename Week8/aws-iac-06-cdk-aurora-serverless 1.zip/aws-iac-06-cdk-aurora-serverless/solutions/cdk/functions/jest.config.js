module.exports = {
  verbose: true, // always print out test names
  clearMocks: true // "false"" is the default for reference
}
