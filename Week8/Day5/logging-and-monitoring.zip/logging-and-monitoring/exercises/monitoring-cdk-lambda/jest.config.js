module.exports = {
  testEnvironment: 'node'
}
