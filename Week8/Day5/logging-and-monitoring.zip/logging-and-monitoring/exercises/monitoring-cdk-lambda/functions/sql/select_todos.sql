SELECT * FROM todo;
