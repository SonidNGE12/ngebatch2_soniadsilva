# React Router Example App

## Running the code

- Check you are in the correct directory: `./examples/react-router`
- Install the necessary dependencies by running `npm install`
- Run the app by running `npm run dev`
