#!/bin/sh

export POSTGRES_DB="localhost"
export POSTGRES_PASSWORD="mysecretpassword"

npm run start
